import { useMemo, useState, type DragEvent, type ReactNode } from "react";

type Screen =
  | "explore"
  | "planner"
  | "bookings"
  | "profile"
  | "detail"
  | "service"
  | "destinations"
  | "notifications"
  | "map"
  | "profile-detail";
type IconName =
  | "home"
  | "calendar"
  | "ticket"
  | "user"
  | "search"
  | "bell"
  | "hotel"
  | "plane"
  | "map"
  | "food"
  | "sparkles"
  | "star"
  | "heart"
  | "arrow"
  | "back"
  | "share"
  | "pin"
  | "clock"
  | "wallet"
  | "plus"
  | "more"
  | "sun"
  | "moon"
  | "check"
  | "chevron"
  | "settings"
  | "help"
  | "logout"
  | "lock";

const photos = {
  danang:
    "https://images.unsplash.com/photo-1723142282970-1fd415eec1ad?auto=format&fit=crop&w=1200&q=88",
  hoian:
    "https://images.unsplash.com/photo-1596401057633-54a8fe8ef647?auto=format&fit=crop&w=1200&q=88",
  halong:
    "https://images.unsplash.com/photo-1643029891412-92f9a81a8c16?auto=format&fit=crop&w=1200&q=88",
  mountain:
    "https://images.unsplash.com/photo-1609412058473-c199497c3c5d?auto=format&fit=crop&w=1200&q=88",
};

const hotelPhotos = [
  "https://images.unsplash.com/photo-1718942899965-4fc10607d805?auto=format&fit=crop&w=1200&q=88",
  "https://images.unsplash.com/photo-1627613499512-9bf5a05affcf?auto=format&fit=crop&w=1200&q=88",
  "https://images.unsplash.com/photo-1672752428724-322132604854?auto=format&fit=crop&w=1200&q=88",
];

const destinations = [
  {
    id: "danang",
    name: "Đà Nẵng",
    place: "Thành phố biển đáng sống",
    rating: "4.9",
    price: "1.290.000đ",
    image: photos.danang,
  },
  {
    id: "hoian",
    name: "Hội An",
    place: "Phố cổ rực rỡ sắc màu",
    rating: "4.8",
    price: "890.000đ",
    image: photos.hoian,
  },
  {
    id: "halong",
    name: "Vịnh Hạ Long",
    place: "Kỳ quan giữa biển trời",
    rating: "4.9",
    price: "1.650.000đ",
    image: photos.halong,
  },
];

const categories: { label: string; icon: IconName; color: string }[] = [
  {
    label: "Khách sạn",
    icon: "hotel",
    color: "bg-blue-50 text-blue-600 dark:bg-blue-500/15 dark:text-blue-300",
  },
  {
    label: "Vé máy bay",
    icon: "plane",
    color: "bg-orange-50 text-orange-500 dark:bg-orange-500/15 dark:text-orange-300",
  },
  {
    label: "Tour",
    icon: "map",
    color: "bg-cyan-50 text-cyan-600 dark:bg-cyan-500/15 dark:text-cyan-300",
  },
  {
    label: "Ẩm thực",
    icon: "food",
    color: "bg-amber-50 text-amber-600 dark:bg-amber-500/15 dark:text-amber-300",
  },
  {
    label: "Trải nghiệm ẩn",
    icon: "sparkles",
    color: "bg-violet-50 text-violet-600 dark:bg-violet-500/15 dark:text-violet-300",
  },
];

const initialActivities = [
  {
    id: 1,
    time: "08:00",
    title: "Cà phê buổi sáng",
    place: "43 Factory Coffee Roaster",
    cost: "120.000đ",
    color: "bg-orange-400",
  },
  {
    id: 2,
    time: "10:30",
    title: "Khám phá bán đảo Sơn Trà",
    place: "Chùa Linh Ứng · 8,4 km",
    cost: "Miễn phí",
    color: "bg-blue-500",
  },
  {
    id: 3,
    time: "15:00",
    title: "Tắm biển Mỹ Khê",
    place: "Bãi biển Mỹ Khê",
    cost: "200.000đ",
    color: "bg-cyan-500",
  },
  {
    id: 4,
    time: "19:00",
    title: "Ăn tối bên sông Hàn",
    place: "Nhà hàng Madame Lân",
    cost: "550.000đ",
    color: "bg-violet-500",
  },
];

const activitiesByDaySeed: Record<number, typeof initialActivities> = {
  1: initialActivities,
  2: [
    {
      id: 21,
      time: "08:30",
      title: "Dạo phố cổ buổi sáng",
      place: "Chùa Cầu, Hội An",
      cost: "80.000đ",
      color: "bg-amber-500",
    },
    {
      id: 22,
      time: "11:30",
      title: "Thưởng thức cao lầu",
      place: "Chợ Hội An",
      cost: "180.000đ",
      color: "bg-orange-400",
    },
    {
      id: 23,
      time: "16:30",
      title: "Thả hoa đăng",
      place: "Sông Hoài",
      cost: "150.000đ",
      color: "bg-violet-500",
    },
  ],
  3: [
    {
      id: 31,
      time: "07:30",
      title: "Khởi hành lên Bà Nà",
      place: "Cáp treo Bà Nà Hills",
      cost: "900.000đ",
      color: "bg-blue-500",
    },
    {
      id: 32,
      time: "10:00",
      title: "Check-in Cầu Vàng",
      place: "Vườn Thiên Thai",
      cost: "Đã gồm vé",
      color: "bg-amber-500",
    },
    {
      id: 33,
      time: "14:00",
      title: "Khám phá làng Pháp",
      place: "French Village",
      cost: "350.000đ",
      color: "bg-cyan-500",
    },
  ],
  4: [
    {
      id: 41,
      time: "08:00",
      title: "Ăn sáng & mua đặc sản",
      place: "Chợ Hàn",
      cost: "450.000đ",
      color: "bg-orange-400",
    },
    {
      id: 42,
      time: "11:00",
      title: "Trả phòng khách sạn",
      place: "Khu vực Mỹ Khê",
      cost: "Đã thanh toán",
      color: "bg-emerald-500",
    },
    {
      id: 43,
      time: "13:30",
      title: "Di chuyển ra sân bay",
      place: "Sân bay Quốc tế Đà Nẵng",
      cost: "120.000đ",
      color: "bg-slate-500",
    },
  ],
};

function Icon({
  name,
  size = 22,
  className = "",
}: {
  name: IconName;
  size?: number;
  className?: string;
}) {
  const common = {
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.9,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };
  const paths: Record<IconName, ReactNode> = {
    home: (
      <>
        <path d="m3 10 9-7 9 7" />
        <path d="M5 9v11h14V9M9 20v-6h6v6" />
      </>
    ),
    calendar: (
      <>
        <rect x="3" y="5" width="18" height="16" rx="3" />
        <path d="M7 3v4m10-4v4M3 10h18" />
      </>
    ),
    ticket: (
      <>
        <path d="M4 7a2 2 0 0 0 0 4v6h16v-6a2 2 0 0 0 0-4V5H4Z" />
        <path d="M13 8h3m-3 4h3" />
      </>
    ),
    user: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M4 21a8 8 0 0 1 16 0" />
      </>
    ),
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
    bell: (
      <>
        <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9Z" />
        <path d="M10 21h4" />
      </>
    ),
    hotel: (
      <>
        <path d="M4 20V4h11v16M2 20h20M8 8h3m-3 4h3m7-1h3v9" />
      </>
    ),
    plane: <path d="m22 2-7 19-4-8-8-4Z" />,
    map: (
      <>
        <path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3Z" />
        <path d="M9 3v15m6-12v15" />
      </>
    ),
    food: (
      <>
        <path d="M6 3v8m-3-8v5a3 3 0 0 0 6 0V3m-3 8v10M15 3v18m0-18c4 1 6 4 6 8h-6" />
      </>
    ),
    sparkles: (
      <>
        <path d="m12 3 1.2 3.8L17 8l-3.8 1.2L12 13l-1.2-3.8L7 8l3.8-1.2ZM5 15l.7 2.3L8 18l-2.3.7L5 21l-.7-2.3L2 18l2.3-.7Zm14-1 .8 2.2L22 17l-2.2.8L19 20l-.8-2.2L16 17l2.2-.8Z" />
      </>
    ),
    star: <path d="m12 2.5 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-2.9-5.6 2.9 1.1-6.2L3 9.1l6.2-.9Z" />,
    heart: (
      <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z" />
    ),
    arrow: (
      <>
        <path d="M5 12h14m-6-6 6 6-6 6" />
      </>
    ),
    back: (
      <>
        <path d="M19 12H5m6-6-6 6 6 6" />
      </>
    ),
    share: (
      <>
        <circle cx="18" cy="5" r="3" />
        <circle cx="6" cy="12" r="3" />
        <circle cx="18" cy="19" r="3" />
        <path d="m8.6 10.5 6.8-4m-6.8 7 6.8 4" />
      </>
    ),
    pin: (
      <>
        <path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z" />
        <circle cx="12" cy="10" r="2.5" />
      </>
    ),
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    wallet: (
      <>
        <path d="M3 6h16a2 2 0 0 1 2 2v11H5a2 2 0 0 1-2-2Z" />
        <path d="M3 7V5a2 2 0 0 1 2-2h12v4m0 5h4" />
      </>
    ),
    plus: <path d="M12 5v14M5 12h14" />,
    more: (
      <>
        <circle cx="5" cy="12" r="1" fill="currentColor" />
        <circle cx="12" cy="12" r="1" fill="currentColor" />
        <circle cx="19" cy="12" r="1" fill="currentColor" />
      </>
    ),
    sun: (
      <>
        <circle cx="12" cy="12" r="4" />
        <path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
      </>
    ),
    moon: <path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8Z" />,
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    settings: (
      <>
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" />
      </>
    ),
    help: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M9.7 9a2.5 2.5 0 1 1 3.4 2.3c-.8.3-1.1.9-1.1 1.7m0 4h.01" />
      </>
    ),
    logout: (
      <>
        <path d="M10 4H4v16h6m5-4 4-4-4-4m4 4H9" />
      </>
    ),
    lock: (
      <>
        <rect x="4" y="10" width="16" height="11" rx="3" />
        <path d="M8 10V7a4 4 0 0 1 8 0v3m-4 4v3" />
      </>
    ),
  };
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      aria-hidden="true"
      {...common}
    >
      {paths[name]}
    </svg>
  );
}

function Header({
  dark,
  setDark,
  onNotifications,
}: {
  dark: boolean;
  setDark: (value: boolean) => void;
  onNotifications: () => void;
}) {
  return (
    <header className="flex items-center justify-between px-5 pt-5 pb-4">
      <div className="flex items-center gap-3">
        <div className="grid h-11 w-11 place-items-center rounded-full bg-gradient-to-br from-blue-200 to-cyan-100 p-0.5">
          <img
            className="h-full w-full rounded-full object-cover"
            src={photos.mountain}
            alt="Ảnh đại diện của Minh"
          />
        </div>
        <div>
          <p className="text-xs text-slate-500 dark:text-slate-400">Chào buổi sáng,</p>
          <h1 className="font-bold text-slate-900 dark:text-white">Minh Anh</h1>
        </div>
      </div>
      <div className="flex gap-2">
        <button
          onClick={() => setDark(!dark)}
          className="icon-button"
          aria-label="Chuyển giao diện sáng tối"
        >
          <Icon name={dark ? "sun" : "moon"} size={19} />
        </button>
        <button onClick={onNotifications} className="icon-button relative" aria-label="Thông báo">
          <Icon name="bell" size={19} />
          <span className="absolute right-2.5 top-2.5 h-2 w-2 rounded-full border-2 border-white bg-[#ff6b4a] dark:border-slate-900" />
        </button>
      </div>
    </header>
  );
}

function Explore({
  onDetail,
  onOpenAdvisor,
  onCategory,
  onOpenMap,
  onSeeAll,
  onNotifications,
  dark,
  setDark,
}: {
  onDetail: (destination: (typeof destinations)[number]) => void;
  onOpenAdvisor: () => void;
  onCategory: (category: (typeof categories)[number]) => void;
  onOpenMap: () => void;
  onSeeAll: () => void;
  onNotifications: () => void;
  dark: boolean;
  setDark: (v: boolean) => void;
}) {
  const [query, setQuery] = useState("");
  const results = useMemo(
    () => destinations.filter((item) => item.name.toLowerCase().includes(query.toLowerCase())),
    [query],
  );
  return (
    <div className="pb-28">
      <Header dark={dark} setDark={setDark} onNotifications={onNotifications} />
      <section className="px-5 pt-2">
        <h2 className="max-w-[310px] text-[28px] font-extrabold leading-[1.18] tracking-[-0.03em] text-slate-950 dark:text-white">
          Đi đâu để thấy mình <span className="text-[#0b74e5]">tự do?</span>
        </h2>
        <div className="mt-5 flex items-center gap-3 rounded-2xl border border-slate-100 bg-white px-4 py-3.5 shadow-[0_8px_30px_rgba(15,45,80,0.07)] dark:border-slate-700 dark:bg-slate-800">
          <Icon name="search" className="text-slate-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-sm outline-none placeholder:text-slate-400"
            placeholder="Bạn muốn đi đâu hôm nay?"
          />
          <button
            onClick={onOpenMap}
            className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-blue-50 text-[#0b74e5] dark:bg-blue-500/15"
            aria-label="Tìm trên bản đồ"
          >
            <Icon name="map" size={17} />
          </button>
        </div>
      </section>

      <section className="mt-7">
        <div className="section-title px-5">
          <h3>Khám phá theo cách của bạn</h3>
        </div>
        <div className="hide-scrollbar mt-4 flex gap-4 overflow-x-auto px-5 pb-2">
          {categories.map((item) => (
            <button
              key={item.label}
              onClick={() => onCategory(item)}
              className="flex w-[65px] shrink-0 flex-col items-center gap-2 text-center"
            >
              <span className={`grid h-14 w-14 place-items-center rounded-2xl ${item.color}`}>
                <Icon name={item.icon} size={23} />
              </span>
              <span className="whitespace-nowrap text-[11px] font-semibold text-slate-600 dark:text-slate-300">
                {item.label}
              </span>
            </button>
          ))}
        </div>
      </section>

      <section className="mt-7">
        <div className="section-title px-5">
          <div>
            <h3>{query ? "Kết quả tìm kiếm" : "Điểm đến thịnh hành"}</h3>
            <p>{query ? `${results.length} điểm đến phù hợp` : "Được yêu thích tuần này"}</p>
          </div>
          <button onClick={onSeeAll} className="text-xs font-bold text-[#0b74e5]">
            Xem tất cả
          </button>
        </div>
        <div className="hide-scrollbar mt-4 flex snap-x gap-4 overflow-x-auto px-5 pb-4">
          {results.map((item) => (
            <button onClick={() => onDetail(item)} key={item.id} className="destination-card group">
              <img src={item.image} alt={item.name} />
              <span className="absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full bg-white/90 text-slate-700 backdrop-blur">
                <Icon name="heart" size={18} />
              </span>
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/90 via-slate-900/30 to-transparent px-4 pb-4 pt-16 text-left text-white">
                <div className="flex items-end justify-between">
                  <div>
                    <h4 className="text-lg font-bold">{item.name}</h4>
                    <p className="text-[11px] text-white/75">{item.place}</p>
                  </div>
                  <span className="flex items-center gap-1 rounded-lg bg-white/15 px-2 py-1 text-xs font-bold backdrop-blur">
                    <Icon name="star" size={12} className="fill-amber-400 text-amber-400" />
                    {item.rating}
                  </span>
                </div>
                <p className="mt-2 text-[11px] text-white/70">
                  Từ <strong className="text-sm text-white">{item.price}</strong> / người
                </p>
              </div>
            </button>
          ))}
          {results.length === 0 && (
            <div className="w-full py-10 text-center text-sm text-slate-500">
              Chưa tìm thấy điểm đến phù hợp.
            </div>
          )}
        </div>
      </section>

      <button
        onClick={onOpenAdvisor}
        className="mx-5 mt-5 block w-[calc(100%-2.5rem)] overflow-hidden rounded-2xl bg-[#0b74e5] p-5 text-left text-white shadow-[0_16px_35px_rgba(11,116,229,.24)] transition active:scale-[.98]"
      >
        <div className="flex items-center gap-4">
          <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-white/15">
            <Icon name="sparkles" />
          </div>
          <div className="flex-1">
            <p className="text-xs text-blue-100">Gợi ý dành riêng cho bạn</p>
            <h3 className="mt-0.5 font-bold">Tìm chuyến đi hợp “mood”</h3>
          </div>
          <Icon name="arrow" />
        </div>
      </button>
    </div>
  );
}

function Planner({ destination }: { destination: (typeof destinations)[number] }) {
  const [day, setDay] = useState(1);
  const [showTimeline, setShowTimeline] = useState(false);
  const [selectedTrip, setSelectedTrip] = useState(0);
  const [activitiesByDay, setActivitiesByDay] =
    useState<Record<number, typeof initialActivities>>(activitiesByDaySeed);
  const [modal, setModal] = useState(false);
  const [dragged, setDragged] = useState<number | null>(null);
  const activities = activitiesByDay[day] ?? [];
  const tripDestinations = [
    destination,
    ...destinations.filter((item) => item.id !== destination.id),
  ];
  const tripMeta = [
    { range: "13–15 tháng 8", days: 3, status: "Sắp tới" },
    { range: "23–27 tháng 8", days: 5, status: "Đang lên kế hoạch" },
    { range: "05–08 tháng 9", days: 4, status: "Bản nháp" },
  ];
  const savedTrips = tripDestinations.map((item, index) => ({
    ...item,
    ...tripMeta[index],
  }));
  const currentTrip = savedTrips[selectedTrip];
  const displayActivities =
    selectedTrip === 0
      ? activities
      : activities.map((item, index) => ({
          ...item,
          title:
            [
              `Khám phá ${currentTrip.name}`,
              "Thưởng thức đặc sản địa phương",
              "Dạo chơi và chụp ảnh",
              "Tự do khám phá",
            ][index] ?? item.title,
          place: currentTrip.name,
        }));
  const reorder = (target: number) => {
    if (dragged === null || dragged === target) return;
    const next = [...activities];
    const from = next.findIndex((item) => item.id === dragged);
    const to = next.findIndex((item) => item.id === target);
    const [item] = next.splice(from, 1);
    next.splice(to, 0, item);
    setActivitiesByDay((current) => ({ ...current, [day]: next }));
    setDragged(null);
  };

  if (!showTimeline) {
    return (
      <div className="min-h-screen pb-28">
        <div className="px-5 pb-4 pt-6">
          <h1 className="text-2xl font-extrabold tracking-tight">Các chuyến đi của tôi</h1>
          <p className="mt-1 text-xs text-slate-500">
            Chọn một chuyến để xem lịch trình nhiều ngày.
          </p>
        </div>
        <div className="mt-3 space-y-4 px-5">
          {savedTrips.map((trip, index) => (
            <button
              key={trip.id}
              onClick={() => {
                setSelectedTrip(index);
                setDay(1);
                setShowTimeline(true);
              }}
              className="w-full overflow-hidden rounded-2xl bg-white text-left shadow-[0_7px_24px_rgba(15,45,80,.08)] dark:bg-slate-800"
            >
              <div className="relative h-36">
                <img src={trip.image} alt={trip.name} className="h-full w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 to-transparent" />
                <span className="absolute right-3 top-3 rounded-lg bg-white/90 px-2.5 py-1 text-[9px] font-bold text-[#0b74e5]">
                  {trip.status}
                </span>
                <div className="absolute inset-x-4 bottom-3 text-white">
                  <h2 className="text-lg font-extrabold">{trip.name}</h2>
                  <p className="mt-1 flex items-center gap-1 text-[10px] text-white/80">
                    <Icon name="calendar" size={12} /> {trip.range} · {trip.days} ngày
                  </p>
                </div>
              </div>
              <div className="flex items-center justify-between px-4 py-3">
                <span className="text-[10px] text-slate-500">Nhấn để xem lịch trình chi tiết</span>
                <Icon name="arrow" size={16} className="text-[#0b74e5]" />
              </div>
            </button>
          ))}
        </div>
        <button className="mx-5 mt-4 flex w-[calc(100%-2.5rem)] items-center justify-center gap-2 rounded-xl border border-dashed border-blue-200 py-3 text-xs font-bold text-[#0b74e5] dark:border-blue-500/30">
          <Icon name="plus" size={16} /> Thêm chuyến đi
        </button>
      </div>
    );
  }

  if (modal) {
    return (
      <AddActivity
        onClose={() => setModal(false)}
        onAdd={() => {
          setActivitiesByDay((current) => ({
            ...current,
            [day]: [
              ...activities,
              {
                id: Date.now(),
                time: "21:00",
                title: "Dạo biển đêm",
                place: "Công viên Biển Đông",
                cost: "Miễn phí",
                color: "bg-emerald-500",
              },
            ],
          }));
          setModal(false);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen pb-28">
      <div className="flex items-center gap-3 px-5 pb-4 pt-6">
        <button onClick={() => setShowTimeline(false)} className="icon-button shrink-0">
          <Icon name="back" size={19} />
        </button>
        <div className="min-w-0">
          <p className="text-[10px] font-bold text-[#0b74e5]">{currentTrip.range.toUpperCase()}</p>
          <h1 className="mt-1 truncate text-xl font-extrabold">Lịch trình {currentTrip.name}</h1>
        </div>
      </div>
      <div className="hide-scrollbar flex gap-2 overflow-x-auto px-5 pb-2">
        {Array.from({ length: currentTrip.days }, (_, index) => index + 1).map((item) => (
          <button
            key={item}
            onClick={() => setDay(item)}
            className={`min-w-[76px] rounded-xl px-3 py-3 text-center text-xs font-bold ${
              day === item ? "bg-[#0b74e5] text-white" : "bg-white text-slate-500 dark:bg-slate-800"
            }`}
          >
            Ngày {item}
          </button>
        ))}
      </div>
      <div className="mx-5 mt-4 flex items-center justify-between">
        <div>
          <h2 className="text-base font-extrabold">Ngày {day}</h2>
          <p className="mt-0.5 text-[10px] text-slate-500">{activities.length} hoạt động</p>
        </div>
        <span className="flex items-center gap-1 text-xs text-slate-500">
          <Icon name="sun" size={15} className="text-orange-400" /> 31°C
        </span>
      </div>
      {activities.length > 0 ? (
        <div className="relative mx-5 mt-5">
          <div className="absolute bottom-7 left-[25px] top-7 w-px bg-slate-200 dark:bg-slate-700" />
          {displayActivities.map((item) => (
            <div
              key={item.id}
              draggable
              onDragStart={() => setDragged(item.id)}
              onDragOver={(e: DragEvent) => e.preventDefault()}
              onDrop={() => reorder(item.id)}
              className="group relative mb-3 flex cursor-grab gap-3 active:cursor-grabbing"
            >
              <div
                className={`z-10 mt-5 h-3 w-3 shrink-0 rounded-full ring-4 ring-[#f6f8fb] dark:ring-slate-950 ${item.color}`}
              />
              <span className="mt-4 w-10 shrink-0 text-xs font-bold text-slate-500">
                {item.time}
              </span>
              <div className="flex-1 rounded-2xl border border-slate-100 bg-white p-4 shadow-[0_6px_20px_rgba(15,45,80,.05)] transition group-active:scale-[.98] dark:border-slate-800 dark:bg-slate-800">
                <div className="flex justify-between gap-2">
                  <h3 className="text-sm font-bold">{item.title}</h3>
                  <Icon name="more" size={17} className="text-slate-400" />
                </div>
                <p className="mt-1.5 flex items-center gap-1 text-[11px] text-slate-500">
                  <Icon name="pin" size={13} />
                  {item.place}
                </p>
                <p className="mt-2 flex items-center gap-1 text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                  <Icon name="wallet" size={13} className="text-[#ff6b4a]" />
                  {item.cost}
                </p>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <EmptyDay onAdd={() => setModal(true)} />
      )}
      <button
        onClick={() => setModal(true)}
        className="fixed bottom-24 left-1/2 z-30 ml-[145px] grid h-14 w-14 -translate-x-1/2 place-items-center rounded-2xl bg-[#ff6b4a] text-white shadow-[0_10px_24px_rgba(255,107,74,.38)] transition active:scale-95"
        aria-label="Thêm hoạt động"
      >
        <Icon name="plus" size={27} />
      </button>
    </div>
  );
}

function EmptyDay({ onAdd }: { onAdd: () => void }) {
  return (
    <div className="mx-5 mt-10 rounded-3xl border border-dashed border-slate-200 px-6 py-12 text-center dark:border-slate-700">
      <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-blue-50 text-[#0b74e5] dark:bg-blue-500/15">
        <Icon name="calendar" />
      </div>
      <h3 className="mt-4 font-bold">Ngày này vẫn còn trống</h3>
      <p className="mx-auto mt-2 max-w-[240px] text-xs leading-5 text-slate-500">
        Thêm một địa điểm thú vị để chuyến đi thêm đáng nhớ.
      </p>
      <button
        onClick={onAdd}
        className="mt-5 rounded-xl bg-[#0b74e5] px-5 py-3 text-xs font-bold text-white"
      >
        Thêm hoạt động
      </button>
    </div>
  );
}

function AddActivity({ onClose, onAdd }: { onClose: () => void; onAdd: () => void }) {
  return (
    <div className="min-h-screen bg-[#f6f8fb] px-5 pb-10 pt-6 dark:bg-slate-950">
      <div className="flex items-center gap-3">
        <button onClick={onClose} className="icon-button">
          <Icon name="back" size={19} />
        </button>
        <div>
          <p className="text-[10px] font-bold uppercase tracking-wider text-[#0b74e5]">
            Lịch trình
          </p>
          <h2 className="text-xl font-extrabold">Thêm hoạt động mới</h2>
        </div>
      </div>
      <div className="mt-7 rounded-3xl bg-white p-5 shadow-[0_8px_30px_rgba(15,45,80,.07)] dark:bg-slate-900">
        <div className="mb-5 flex items-center gap-3 rounded-2xl bg-blue-50 p-4 text-[#0b74e5] dark:bg-blue-500/10">
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-white dark:bg-slate-800">
            <Icon name="sparkles" />
          </span>
          <div>
            <p className="text-xs font-extrabold">Gợi ý thông minh</p>
            <p className="mt-1 text-[10px] text-slate-500">Thời điểm này rất hợp để khám phá về đêm.</p>
          </div>
        </div>
        <label className="field-label">
          Tên hoạt động
          <input defaultValue="Dạo biển đêm" />
        </label>
        <div className="grid grid-cols-2 gap-3">
          <label className="field-label">
            Thời gian
            <input type="time" defaultValue="21:00" />
          </label>
          <label className="field-label">
            Chi phí
            <input defaultValue="Miễn phí" />
          </label>
        </div>
        <label className="field-label">
          Địa điểm
          <input defaultValue="Công viên Biển Đông" />
        </label>
        <button
          onClick={onAdd}
          className="mt-5 w-full rounded-2xl bg-[#ff6b4a] py-4 text-sm font-bold text-white shadow-lg shadow-orange-500/20"
        >
          Thêm vào lịch trình
        </button>
      </div>
    </div>
  );
}

function Detail({
  destination,
  onBack,
  onOpenMap,
}: {
  destination: (typeof destinations)[number];
  onBack: () => void;
  onOpenMap: () => void;
}) {
  const [saved, setSaved] = useState(false);
  const [added, setAdded] = useState(false);
  return (
    <div className="pb-10">
      <div className="relative h-[340px] overflow-hidden">
        <img
          src={destination.image}
          className="h-full w-full object-cover"
          alt={destination.name}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950/30 via-transparent to-slate-950/70" />
        <div className="absolute inset-x-0 top-0 flex justify-between p-5 pt-6">
          <button
            onClick={onBack}
            className="flex h-10 items-center gap-1.5 rounded-full bg-white/90 px-3.5 text-xs font-extrabold text-slate-800 shadow-md backdrop-blur-md transition active:scale-95"
            aria-label="Quay lại trang trước"
          >
            <Icon name="back" size={18} />
            Quay lại
          </button>
          <div className="flex gap-2">
            <button className="glass-button">
              <Icon name="share" size={19} />
            </button>
            <button
              onClick={() => setSaved(!saved)}
              className={`glass-button ${saved ? "!bg-[#ff6b4a] !text-white" : ""}`}
            >
              <Icon name="heart" size={19} className={saved ? "fill-current" : ""} />
            </button>
          </div>
        </div>
        <div className="absolute inset-x-5 bottom-6 text-white">
          <span className="rounded-lg bg-[#ff6b4a] px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider">
            Top điểm đến
          </span>
          <h1 className="mt-3 text-3xl font-extrabold tracking-tight">{destination.name}</h1>
          <p className="mt-2 flex items-center gap-1 text-xs text-white/80">
            <Icon name="pin" size={15} />
            Việt Nam · {destination.place}
          </p>
        </div>
      </div>
      <div className="relative -mt-4 rounded-t-[24px] bg-[#f6f8fb] px-5 pt-6 dark:bg-slate-950">
        <div className="flex justify-between rounded-2xl bg-white p-4 shadow-sm dark:bg-slate-800">
          <Stat icon="star" value="4.9" label="2.4k đánh giá" highlight />
          <span className="w-px bg-slate-100 dark:bg-slate-700" />
          <Stat icon="clock" value="2–3 giờ" label="Thời gian đẹp" />
          <span className="w-px bg-slate-100 dark:bg-slate-700" />
          <Stat icon="wallet" value="Miễn phí" label="Vào cửa" />
        </div>
        <section className="mt-7">
          <h2 className="text-lg font-extrabold">Về địa điểm này</h2>
          <p className="mt-2 text-sm leading-6 text-slate-500 dark:text-slate-400">
            Một trong những bãi biển quyến rũ nhất hành tinh với bờ cát trắng mịn, làn nước xanh
            trong và nhịp sống trẻ trung. Thời điểm lý tưởng nhất là bình minh.
          </p>
        </section>
        <section className="mt-7">
          <div className="section-title">
            <h3>Vị trí</h3>
            <button onClick={onOpenMap} className="text-xs font-bold text-[#0b74e5]">
              Mở bản đồ
            </button>
          </div>
          <div className="map-card mt-3">
            <div className="map-road road-one" />
            <div className="map-road road-two" />
            <div className="map-road road-three" />
            <div className="absolute left-[55%] top-[38%] grid h-11 w-11 place-items-center rounded-full bg-[#0b74e5] text-white shadow-lg ring-4 ring-white/70">
              <Icon name="pin" size={21} />
            </div>
            <div className="absolute bottom-3 left-3 rounded-xl bg-white/95 px-3 py-2 shadow-md dark:bg-slate-800/95">
              <p className="text-[11px] font-bold">Bãi biển Mỹ Khê</p>
              <p className="mt-0.5 text-[9px] text-slate-500">Cách bạn 2,4 km</p>
            </div>
          </div>
        </section>
        <section className="mt-7">
          <div className="section-title">
            <h3>Cộng đồng nói gì</h3>
            <button className="text-xs font-bold text-[#0b74e5]">Xem 2.4k đánh giá</button>
          </div>
          <div className="mt-3 rounded-2xl bg-white p-4 dark:bg-slate-800">
            <div className="flex items-center gap-3">
              <img src={photos.hoian} className="h-9 w-9 rounded-full object-cover" alt="" />
              <div className="flex-1">
                <p className="text-xs font-bold">Linh Nguyễn</p>
                <p className="text-[10px] text-slate-400">2 ngày trước</p>
              </div>
              <span className="flex items-center gap-1 text-xs font-bold">
                <Icon name="star" size={12} className="fill-amber-400 text-amber-400" />
                5.0
              </span>
            </div>
            <p className="mt-3 text-xs leading-5 text-slate-600 dark:text-slate-300">
              Biển rất sạch và yên bình vào sáng sớm. Nhất định nên dậy sớm ngắm bình minh một lần!
            </p>
          </div>
        </section>
        <div className="sticky bottom-4 mt-7 flex gap-3 rounded-2xl bg-white/90 p-2 shadow-[0_8px_30px_rgba(15,45,80,.15)] backdrop-blur dark:bg-slate-800/90">
          <button
            onClick={() => setSaved(!saved)}
            className={`grid h-12 w-12 shrink-0 place-items-center rounded-xl border ${saved ? "border-orange-200 bg-orange-50 text-[#ff6b4a]" : "border-slate-200 text-slate-500 dark:border-slate-700"}`}
          >
            <Icon name="heart" className={saved ? "fill-current" : ""} />
          </button>
          <button
            onClick={() => setAdded(true)}
            className={`flex h-12 flex-1 items-center justify-center gap-2 rounded-xl text-sm font-bold text-white transition ${added ? "bg-emerald-500" : "bg-[#0b74e5]"}`}
          >
            <Icon name={added ? "check" : "plus"} size={19} />
            {added ? "Đã thêm vào lịch trình" : "Thêm vào lịch trình"}
          </button>
        </div>
      </div>
    </div>
  );
}

function Stat({
  icon,
  value,
  label,
  highlight = false,
}: {
  icon: IconName;
  value: string;
  label: string;
  highlight?: boolean;
}) {
  return (
    <div className="flex-1 text-center">
      <div className="flex items-center justify-center gap-1">
        <Icon
          name={icon}
          size={14}
          className={highlight ? "fill-amber-400 text-amber-400" : "text-[#0b74e5]"}
        />
        <strong className="text-xs">{value}</strong>
      </div>
      <p className="mt-1 text-[9px] text-slate-400">{label}</p>
    </div>
  );
}

function Bookings({ destination }: { destination: (typeof destinations)[number] }) {
  const [filter, setFilter] = useState("Tất cả");
  const [selectedHotel, setSelectedHotel] = useState<number | null>(null);
  const [confirmed, setConfirmed] = useState<number | null>(null);
  const hotelNames: Record<string, string[]> = {
    danang: ["Sala Beach Hotel", "Naman Retreat", "The Ocean Suites"],
    hoian: ["Anantara Hội An", "La Siesta Resort", "Silk Sense River Resort"],
    halong: ["Oakwood Hạ Long", "Vinpearl Resort & Spa", "Citadines Marina"],
  };
  const areaNames: Record<string, string[]> = {
    danang: ["Mỹ Khê · Cách biển 120 m", "Ngũ Hành Sơn · Cách 4,2 km", "Sơn Trà · Cách biển 350 m"],
    hoian: ["Ven sông Thu Bồn · Cách 800 m", "Phố cổ · Cách 1,1 km", "Cẩm An · Cách biển 600 m"],
    halong: ["Bãi Cháy · Hướng vịnh", "Đảo Rều · Bãi biển riêng", "Hùng Thắng · Gần bến du thuyền"],
  };
  const names = hotelNames[destination.id] ?? hotelNames.danang;
  const areas = areaNames[destination.id] ?? areaNames.danang;
  const stays = names.map((name, index) => ({
    id: index,
    name,
    area: areas[index],
    image: hotelPhotos[index],
    rating: ["4.9", "4.8", "4.7"][index],
    reviews: ["1.284", "896", "642"][index],
    price: [1890000, 2450000, 1320000][index],
    oldPrice: [2300000, 2900000, 1650000][index],
    badge: ["Được yêu thích", "Nghỉ dưỡng cao cấp", "Giá tốt hôm nay"][index],
    amenity: ["Hồ bơi vô cực · Ăn sáng", "Bãi biển riêng · Spa", "View biển · Xe đưa đón"][index],
  }));
  const visibleStays = filter === "Giá tốt" ? [...stays].sort((a, b) => a.price - b.price) : stays;
  const hotel = selectedHotel === null ? null : stays.find((item) => item.id === selectedHotel);
  const formatPrice = (value: number) => `${value.toLocaleString("vi-VN")}đ`;

  return (
    <>
      <div className="pb-28 pt-6">
        <div className="px-5">
          <p className="text-xs font-semibold uppercase tracking-[.12em] text-[#0b74e5]">
            Lưu trú tại {destination.name}
          </p>
          <h1 className="mt-1 text-2xl font-extrabold">Chọn nơi để nghỉ ngơi</h1>
          <p className="mt-1 text-xs leading-5 text-slate-500">12–15 tháng 8 · 2 khách · 1 phòng</p>
          <div className="mt-5 flex items-center gap-3 rounded-2xl border border-slate-100 bg-white px-4 py-3.5 shadow-sm dark:border-slate-700 dark:bg-slate-800">
            <Icon name="search" size={19} className="text-slate-400" />
            <input
              className="w-full bg-transparent text-xs outline-none"
              placeholder={`Tìm khách sạn tại ${destination.name}`}
            />
            <button className="text-[#0b74e5]">
              <Icon name="settings" size={18} />
            </button>
          </div>
        </div>

        <div className="hide-scrollbar mt-4 flex gap-2 overflow-x-auto px-5 pb-2">
          {["Tất cả", "Giá tốt", "Gần trung tâm", "Hồ bơi", "4–5 sao"].map((item) => (
            <button
              key={item}
              onClick={() => setFilter(item)}
              className={`shrink-0 rounded-full px-4 py-2 text-[11px] font-bold transition ${
                filter === item
                  ? "bg-[#0b74e5] text-white shadow-md shadow-blue-500/20"
                  : "border border-slate-200 bg-white text-slate-500 dark:border-slate-700 dark:bg-slate-800"
              }`}
            >
              {item}
            </button>
          ))}
        </div>

        <div className="mt-5 flex items-center justify-between px-5">
          <div>
            <h2 className="text-base font-extrabold">{visibleStays.length} nơi phù hợp nhất</h2>
            <p className="mt-0.5 text-[10px] text-slate-400">Đề xuất theo lịch trình của bạn</p>
          </div>
          <button className="flex items-center gap-1 text-[10px] font-bold text-[#0b74e5]">
            Bản đồ <Icon name="map" size={14} />
          </button>
        </div>

        <div className="mt-4 space-y-4 px-5">
          {visibleStays.map((item) => (
            <button
              key={item.id}
              onClick={() => setSelectedHotel(item.id)}
              className="w-full overflow-hidden rounded-3xl bg-white text-left shadow-[0_8px_28px_rgba(15,45,80,.08)] transition active:scale-[.99] dark:bg-slate-800"
            >
              <div className="relative h-44">
                <img src={item.image} alt={item.name} className="h-full w-full object-cover" />
                <span className="absolute left-3 top-3 rounded-lg bg-white/90 px-2.5 py-1.5 text-[9px] font-extrabold text-[#0b74e5] backdrop-blur">
                  {item.badge}
                </span>
                <span className="absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full bg-white/90 text-slate-600 backdrop-blur">
                  <Icon name="heart" size={17} />
                </span>
                {confirmed === item.id && (
                  <span className="absolute bottom-3 left-3 flex items-center gap-1 rounded-lg bg-emerald-500 px-2.5 py-1.5 text-[9px] font-extrabold text-white">
                    <Icon name="check" size={12} /> ĐÃ ĐẶT TRƯỚC
                  </span>
                )}
              </div>
              <div className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-extrabold">{item.name}</h3>
                    <p className="mt-1 flex items-center gap-1 text-[10px] text-slate-500">
                      <Icon name="pin" size={12} /> {item.area}
                    </p>
                  </div>
                  <span className="flex shrink-0 items-center gap-1 rounded-lg bg-blue-50 px-2 py-1 text-[10px] font-bold text-[#0b74e5] dark:bg-blue-500/15">
                    <Icon name="star" size={11} className="fill-amber-400 text-amber-400" />
                    {item.rating}
                  </span>
                </div>
                <p className="mt-3 flex items-center gap-1.5 text-[10px] text-slate-500">
                  <Icon name="sparkles" size={13} className="text-[#ff6b4a]" /> {item.amenity}
                </p>
                <div className="mt-4 flex items-end justify-between border-t border-slate-100 pt-3 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400">{item.reviews} đánh giá</span>
                  <div className="text-right">
                    <span className="block text-[9px] text-slate-400 line-through">
                      {formatPrice(item.oldPrice)}
                    </span>
                    <strong className="text-base text-[#0b74e5]">{formatPrice(item.price)}</strong>
                    <span className="text-[9px] text-slate-400"> / đêm</span>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {hotel && (
        <div className="fixed inset-0 z-[60] flex justify-center bg-[#f6f8fb] dark:bg-slate-950">
          <div
            className="min-h-screen w-full max-w-[480px] overflow-y-auto bg-[#f6f8fb] pb-7 dark:bg-slate-950"
          >
            <div className="relative h-64">
              <img src={hotel.image} alt={hotel.name} className="h-full w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 to-transparent" />
              <button
                onClick={() => setSelectedHotel(null)}
                className="glass-button absolute left-5 top-5"
              >
                <Icon name="back" />
              </button>
              <button className="glass-button absolute right-5 top-5">
                <Icon name="heart" size={19} />
              </button>
              <div className="absolute inset-x-5 bottom-5 text-white">
                <p className="text-[10px] font-bold text-blue-100">{destination.name}</p>
                <h2 className="mt-1 text-2xl font-extrabold">{hotel.name}</h2>
              </div>
            </div>
            <div className="px-5 pt-5">
              {confirmed === hotel.id ? (
                <div className="rounded-3xl bg-white p-6 text-center shadow-sm dark:bg-slate-800">
                  <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-emerald-50 text-emerald-600 dark:bg-emerald-500/15">
                    <Icon name="check" size={30} />
                  </div>
                  <h3 className="mt-4 text-xl font-extrabold">Đã giữ chỗ thành công!</h3>
                  <p className="mt-2 text-xs leading-5 text-slate-500">
                    {hotel.name} đã được thêm vào chuyến đi {destination.name} của bạn.
                  </p>
                  <div className="mt-5 rounded-2xl bg-slate-50 p-4 text-left dark:bg-slate-900">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-500">Mã đặt chỗ</span>
                      <strong>WG0825{hotel.id + 24}</strong>
                    </div>
                    <div className="mt-3 flex justify-between text-xs">
                      <span className="text-slate-500">Tổng tạm tính</span>
                      <strong>{formatPrice(hotel.price * 3)}</strong>
                    </div>
                  </div>
                  <button onClick={() => setSelectedHotel(null)} className="advisor-primary mt-5">
                    Hoàn tất
                  </button>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between">
                    <p className="flex items-center gap-1 text-xs font-bold">
                      <Icon name="star" size={14} className="fill-amber-400 text-amber-400" />
                      {hotel.rating}{" "}
                      <span className="font-normal text-slate-400">· {hotel.reviews} đánh giá</span>
                    </p>
                    <span className="rounded-lg bg-emerald-50 px-2.5 py-1 text-[10px] font-bold text-emerald-600 dark:bg-emerald-500/15">
                      Miễn phí hủy
                    </span>
                  </div>
                  <div className="mt-5 grid grid-cols-3 gap-2">
                    {["Ăn sáng", "Hồ bơi", "Wi-Fi miễn phí"].map((item, index) => (
                      <div
                        key={item}
                        className="rounded-xl bg-white px-2 py-3 text-center dark:bg-slate-800"
                      >
                        <Icon
                          name={index === 0 ? "food" : index === 1 ? "sparkles" : "hotel"}
                          size={17}
                          className="mx-auto text-[#0b74e5]"
                        />
                        <p className="mt-1.5 text-[9px] font-semibold">{item}</p>
                      </div>
                    ))}
                  </div>
                  <div className="mt-5 rounded-2xl bg-white p-4 dark:bg-slate-800">
                    <h3 className="text-sm font-extrabold">Phòng Deluxe hướng biển</h3>
                    <p className="mt-1 text-[10px] text-slate-500">
                      1 giường đôi · 2 khách · 32 m²
                    </p>
                    <div className="mt-4 grid grid-cols-2 gap-3 border-t border-slate-100 pt-4 dark:border-slate-700">
                      <div>
                        <p className="text-[9px] text-slate-400">NHẬN PHÒNG</p>
                        <strong className="mt-1 block text-xs">12 Thg 8 · 14:00</strong>
                      </div>
                      <div>
                        <p className="text-[9px] text-slate-400">TRẢ PHÒNG</p>
                        <strong className="mt-1 block text-xs">15 Thg 8 · 12:00</strong>
                      </div>
                    </div>
                  </div>
                  <div className="mt-5 flex items-end justify-between">
                    <div>
                      <p className="text-[10px] text-slate-400">Tổng 3 đêm, đã gồm thuế</p>
                      <strong className="text-xl text-[#0b74e5]">
                        {formatPrice(hotel.price * 3)}
                      </strong>
                    </div>
                    <button
                      onClick={() => setConfirmed(hotel.id)}
                      className="rounded-2xl bg-[#ff6b4a] px-6 py-4 text-xs font-extrabold text-white shadow-lg shadow-orange-500/20"
                    >
                      Đặt trước ngay
                    </button>
                  </div>
                  <p className="mt-3 text-center text-[9px] text-slate-400">
                    Bản demo · Chưa phát sinh thanh toán thực tế
                  </p>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function Profile({
  dark,
  setDark,
  onOpenItem,
}: {
  dark: boolean;
  setDark: (value: boolean) => void;
  onOpenItem: (label: string) => void;
}) {
  const items: { icon: IconName; label: string; note?: string }[] = [
    { icon: "heart", label: "Địa điểm đã lưu", note: "12" },
    { icon: "settings", label: "Cài đặt tài khoản" },
    { icon: "help", label: "Trợ giúp & hỗ trợ" },
    { icon: "logout", label: "Đăng xuất" },
  ];
  return (
    <div className="pb-28">
      <div className="bg-[#0b74e5] px-5 pb-16 pt-7 text-white">
        <div className="flex justify-between">
          <div>
            <p className="text-xs text-blue-100">Hồ sơ của tôi</p>
            <h1 className="mt-1 text-2xl font-extrabold">Minh Anh</h1>
          </div>
          <button onClick={() => setDark(!dark)} className="glass-button">
            <Icon name={dark ? "sun" : "moon"} />
          </button>
        </div>
      </div>
      <div className="mx-5 -mt-10 rounded-3xl bg-white p-5 text-center shadow-[0_10px_35px_rgba(15,45,80,.1)] dark:bg-slate-800">
        <img
          src={photos.mountain}
          className="mx-auto h-20 w-20 rounded-full border-4 border-white object-cover shadow-md dark:border-slate-800"
          alt="Minh Anh"
        />
        <h2 className="mt-3 text-lg font-extrabold">Minh Anh Nguyễn</h2>
        <p className="mt-1 text-xs text-slate-500">minhanh@waygo.vn</p>
        <div className="mt-5 grid grid-cols-3 divide-x divide-slate-100 dark:divide-slate-700">
          <div>
            <strong className="text-lg">8</strong>
            <p className="text-[10px] text-slate-400">Chuyến đi</p>
          </div>
          <div>
            <strong className="text-lg">12</strong>
            <p className="text-[10px] text-slate-400">Đã lưu</p>
          </div>
          <div>
            <strong className="text-lg">6</strong>
            <p className="text-[10px] text-slate-400">Đánh giá</p>
          </div>
        </div>
      </div>
      <div className="mx-5 mt-5 rounded-2xl bg-white px-4 dark:bg-slate-800">
        {items.map((item, index) => (
          <button
            key={item.label}
            onClick={() => onOpenItem(item.label)}
            className={`flex w-full items-center gap-3 py-4 text-left ${index < items.length - 1 ? "border-b border-slate-100 dark:border-slate-700" : ""}`}
          >
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-slate-50 text-[#0b74e5] dark:bg-slate-700">
              <Icon name={item.icon} size={18} />
            </span>
            <span className="flex-1 text-sm font-semibold">{item.label}</span>
            {item.note && <span className="text-xs text-slate-400">{item.note}</span>}
            <Icon name="chevron" size={16} className="text-slate-300" />
          </button>
        ))}
      </div>
    </div>
  );
}

function PageHeader({
  title,
  eyebrow,
  onBack,
}: {
  title: string;
  eyebrow?: string;
  onBack: () => void;
}) {
  return (
    <div className="flex items-center gap-3 px-5 pb-4 pt-6">
      <button onClick={onBack} className="icon-button shrink-0" aria-label="Quay lại">
        <Icon name="back" size={19} />
      </button>
      <div className="min-w-0">
        {eyebrow && (
          <p className="text-[10px] font-bold uppercase tracking-[.12em] text-[#0b74e5]">
            {eyebrow}
          </p>
        )}
        <h1 className="truncate text-xl font-extrabold">{title}</h1>
      </div>
    </div>
  );
}

function DestinationsPage({
  onBack,
  onDetail,
}: {
  onBack: () => void;
  onDetail: (destination: (typeof destinations)[number]) => void;
}) {
  const [filter, setFilter] = useState("Tất cả");
  return (
    <div className="min-h-screen pb-8">
      <PageHeader title="Điểm đến nổi bật" eyebrow="Khám phá Việt Nam" onBack={onBack} />
      <div className="hide-scrollbar flex gap-2 overflow-x-auto px-5 pb-2">
        {["Tất cả", "Biển", "Văn hóa", "Thiên nhiên"].map((item) => (
          <button
            key={item}
            onClick={() => setFilter(item)}
            className={`shrink-0 rounded-full px-4 py-2 text-[11px] font-bold ${
              filter === item
                ? "bg-[#0b74e5] text-white"
                : "border border-slate-200 bg-white text-slate-500 dark:border-slate-700 dark:bg-slate-800"
            }`}
          >
            {item}
          </button>
        ))}
      </div>
      <div className="mt-5 space-y-4 px-5">
        {destinations.map((item, index) => (
          <button
            key={item.id}
            onClick={() => onDetail(item)}
            className="group relative h-56 w-full overflow-hidden rounded-3xl text-left shadow-[0_10px_28px_rgba(15,45,80,.12)]"
          >
            <img
              src={item.image}
              alt={item.name}
              className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
            />
            <span className="absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1.5 text-[10px] font-extrabold text-[#0b74e5]">
              {["Đang thịnh hành", "Phù hợp cặp đôi", "Kỳ quan thiên nhiên"][index]}
            </span>
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-transparent to-transparent" />
            <div className="absolute inset-x-4 bottom-4 text-white">
              <div className="flex items-end justify-between">
                <div>
                  <h2 className="text-xl font-extrabold">{item.name}</h2>
                  <p className="mt-1 text-[10px] text-white/75">{item.place}</p>
                </div>
                <span className="flex items-center gap-1 text-xs font-bold">
                  <Icon name="star" size={13} className="fill-amber-400 text-amber-400" />
                  {item.rating}
                </span>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

const serviceContent: Record<
  string,
  { subtitle: string; items: { title: string; note: string; price: string; image: string }[] }
> = {
  "Khách sạn": {
    subtitle: "Nơi nghỉ được yêu thích",
    items: [
      { title: "Sala Beach Hotel", note: "Mỹ Khê · Hồ bơi vô cực", price: "1.890.000đ", image: hotelPhotos[0] },
      { title: "Naman Retreat", note: "Bãi biển riêng · Spa", price: "2.450.000đ", image: hotelPhotos[1] },
      { title: "The Ocean Suites", note: "View biển · Ăn sáng", price: "1.320.000đ", image: hotelPhotos[2] },
    ],
  },
  "Vé máy bay": {
    subtitle: "Chuyến bay giá tốt hôm nay",
    items: [
      { title: "Hà Nội → Đà Nẵng", note: "08:15 – 09:40 · Bay thẳng", price: "1.290.000đ", image: photos.danang },
      { title: "TP.HCM → Đà Nẵng", note: "10:30 – 11:55 · Bay thẳng", price: "990.000đ", image: photos.mountain },
      { title: "Hà Nội → Hội An", note: "14:10 – 15:35 · Đến Đà Nẵng", price: "1.450.000đ", image: photos.hoian },
    ],
  },
  Tour: {
    subtitle: "Hành trình được chọn nhiều",
    items: [
      { title: "Sơn Trà & Ngũ Hành Sơn", note: "8 giờ · Nhóm tối đa 10 khách", price: "790.000đ", image: photos.danang },
      { title: "Một ngày làm người Hội An", note: "6 giờ · Có hướng dẫn viên", price: "650.000đ", image: photos.hoian },
      { title: "Du thuyền kỳ quan Hạ Long", note: "2 ngày 1 đêm · Trọn gói", price: "2.890.000đ", image: photos.halong },
    ],
  },
  "Ẩm thực": {
    subtitle: "Hương vị không nên bỏ lỡ",
    items: [
      { title: "Food tour Đà Nẵng", note: "4 điểm ăn · 3 giờ", price: "490.000đ", image: photos.danang },
      { title: "Lớp nấu cao lầu", note: "Chợ Hội An · Bao gồm nguyên liệu", price: "620.000đ", image: photos.hoian },
      { title: "Bữa tối hải sản bên vịnh", note: "Set menu · 2 khách", price: "890.000đ", image: photos.halong },
    ],
  },
  "Trải nghiệm ẩn": {
    subtitle: "Những góc riêng chỉ Waygo biết",
    items: [
      { title: "Ngắm bình minh cùng ngư dân", note: "05:00 · Bãi biển Mân Thái", price: "350.000đ", image: photos.danang },
      { title: "Đạp xe xuyên làng rau", note: "07:30 · Trà Quế, Hội An", price: "280.000đ", image: photos.hoian },
      { title: "Chèo kayak qua hang Luồn", note: "15:00 · Vịnh Hạ Long", price: "450.000đ", image: photos.halong },
    ],
  },
};

function ServicePage({
  category,
  onBack,
}: {
  category: (typeof categories)[number];
  onBack: () => void;
}) {
  const content = serviceContent[category.label] ?? serviceContent.Tour;
  const [selected, setSelected] = useState<number | null>(null);
  return (
    <div className="min-h-screen pb-10">
      <PageHeader title={category.label} eyebrow="Dịch vụ Waygo" onBack={onBack} />
      <div className="px-5">
        <div className="flex items-center gap-3 rounded-2xl border border-slate-100 bg-white px-4 py-3.5 shadow-sm dark:border-slate-700 dark:bg-slate-800">
          <Icon name="search" size={19} className="text-slate-400" />
          <input
            className="w-full bg-transparent text-xs outline-none"
            placeholder={`Tìm ${category.label.toLowerCase()} phù hợp`}
          />
          <Icon name="settings" size={18} className="text-[#0b74e5]" />
        </div>
        <div className="mt-5 rounded-3xl bg-gradient-to-br from-[#0b74e5] to-cyan-500 p-5 text-white">
          <span className="grid h-11 w-11 place-items-center rounded-2xl bg-white/15">
            <Icon name={category.icon} />
          </span>
          <h2 className="mt-4 text-xl font-extrabold">{content.subtitle}</h2>
          <p className="mt-1 text-xs text-blue-100">Được cá nhân hóa theo chuyến đi của bạn.</p>
        </div>
      </div>
      <div className="mt-6 space-y-4 px-5">
        {content.items.map((item, index) => (
          <article
            key={item.title}
            className="overflow-hidden rounded-3xl bg-white shadow-[0_8px_26px_rgba(15,45,80,.08)] dark:bg-slate-800"
          >
            <img src={item.image} alt={item.title} className="h-40 w-full object-cover" />
            <div className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-sm font-extrabold">{item.title}</h3>
                  <p className="mt-1 text-[10px] text-slate-500">{item.note}</p>
                </div>
                <span className="flex items-center gap-1 text-[10px] font-bold">
                  <Icon name="star" size={11} className="fill-amber-400 text-amber-400" /> 4.{9 - index}
                </span>
              </div>
              <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3 dark:border-slate-700">
                <div>
                  <p className="text-[9px] text-slate-400">Từ</p>
                  <strong className="text-sm text-[#0b74e5]">{item.price}</strong>
                </div>
                <button
                  onClick={() => setSelected(index)}
                  className={`rounded-xl px-4 py-2.5 text-[11px] font-extrabold text-white ${
                    selected === index ? "bg-emerald-500" : "bg-[#ff6b4a]"
                  }`}
                >
                  {selected === index ? "Đã chọn" : "Xem & chọn"}
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

function MapPage({ onBack }: { onBack: () => void }) {
  const [selected, setSelected] = useState(0);
  return (
    <div className="min-h-screen">
      <PageHeader title="Bản đồ khám phá" eyebrow="Gần bạn" onBack={onBack} />
      <div className="relative mx-5 h-[430px] overflow-hidden rounded-[28px] bg-[#dcecf1] dark:bg-slate-800">
        <div className="map-card !h-full !rounded-none">
          <div className="map-road road-one" />
          <div className="map-road road-two" />
          <div className="map-road road-three" />
          {[
            ["25%", "28%"],
            ["65%", "42%"],
            ["40%", "70%"],
          ].map(([left, top], index) => (
            <button
              key={left}
              onClick={() => setSelected(index)}
              style={{ left, top }}
              className={`absolute grid h-11 w-11 place-items-center rounded-full text-white shadow-lg ring-4 ring-white/70 ${
                selected === index ? "scale-110 bg-[#ff6b4a]" : "bg-[#0b74e5]"
              }`}
            >
              <Icon name="pin" size={20} />
            </button>
          ))}
        </div>
      </div>
      <div className="mx-5 -mt-12 relative rounded-2xl bg-white p-4 shadow-xl dark:bg-slate-900">
        <div className="flex gap-3">
          <img src={destinations[selected].image} alt="" className="h-20 w-20 rounded-xl object-cover" />
          <div className="flex-1">
            <p className="text-[10px] font-bold text-[#0b74e5]">ĐIỂM ĐẾN GỢI Ý</p>
            <h2 className="mt-1 font-extrabold">{destinations[selected].name}</h2>
            <p className="mt-1 text-[10px] text-slate-500">{destinations[selected].place}</p>
            <p className="mt-2 text-[10px] font-bold text-[#ff6b4a]">Cách bạn 2,4 km</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function NotificationsPage({ onBack }: { onBack: () => void }) {
  const notices = [
    ["Giá khách sạn vừa giảm", "Sala Beach Hotel đang giảm 18% cho ngày bạn đã chọn.", "hotel"],
    ["Lịch trình đã sẵn sàng", "Waygo đã tối ưu lộ trình ngày 2 tại Hội An.", "sparkles"],
    ["Sắp đến giờ khởi hành", "Chuyến bay tới Đà Nẵng còn 2 ngày nữa.", "plane"],
  ] as const;
  return (
    <div className="min-h-screen">
      <PageHeader title="Thông báo" eyebrow="3 cập nhật mới" onBack={onBack} />
      <div className="space-y-3 px-5">
        {notices.map(([title, note, icon], index) => (
          <button
            key={title}
            className="flex w-full gap-3 rounded-2xl bg-white p-4 text-left shadow-sm dark:bg-slate-800"
          >
            <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl ${index === 0 ? "bg-orange-50 text-[#ff6b4a]" : "bg-blue-50 text-[#0b74e5]"} dark:bg-slate-700`}>
              <Icon name={icon} size={19} />
            </span>
            <span className="flex-1">
              <strong className="text-xs">{title}</strong>
              <span className="mt-1 block text-[10px] leading-4 text-slate-500">{note}</span>
              <span className="mt-2 block text-[9px] text-slate-400">{index + 1} giờ trước</span>
            </span>
            <span className="mt-1 h-2 w-2 rounded-full bg-[#ff6b4a]" />
          </button>
        ))}
      </div>
    </div>
  );
}

function ProfileDetailPage({ title, onBack }: { title: string; onBack: () => void }) {
  const isSaved = title === "Địa điểm đã lưu";
  return (
    <div className="min-h-screen pb-10">
      <PageHeader title={title} eyebrow="Tài khoản Waygo" onBack={onBack} />
      {isSaved ? (
        <div className="space-y-3 px-5">
          {destinations.map((item) => (
            <div key={item.id} className="flex gap-3 rounded-2xl bg-white p-3 dark:bg-slate-800">
              <img src={item.image} alt={item.name} className="h-20 w-24 rounded-xl object-cover" />
              <div className="flex-1 py-1">
                <h2 className="text-sm font-extrabold">{item.name}</h2>
                <p className="mt-1 text-[10px] text-slate-500">{item.place}</p>
                <p className="mt-3 flex items-center gap-1 text-[10px] font-bold text-[#ff6b4a]">
                  <Icon name="heart" size={12} className="fill-current" /> Đã lưu
                </p>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="mx-5 rounded-3xl bg-white p-5 shadow-sm dark:bg-slate-800">
          {title === "Cài đặt tài khoản" ? (
            <>
              <label className="field-label !mt-0">Họ và tên<input defaultValue="Minh Anh Nguyễn" /></label>
              <label className="field-label">Email<input defaultValue="minhanh@waygo.vn" /></label>
              <label className="field-label">Số điện thoại<input defaultValue="0912 345 678" /></label>
              <button className="advisor-primary mt-6">Lưu thay đổi</button>
            </>
          ) : (
            <div className="py-5 text-center">
              <span className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-blue-50 text-[#0b74e5] dark:bg-blue-500/15">
                <Icon name={title === "Đăng xuất" ? "logout" : "help"} size={28} />
              </span>
              <h2 className="mt-4 text-lg font-extrabold">
                {title === "Đăng xuất" ? "Bạn muốn đăng xuất?" : "Waygo luôn ở đây hỗ trợ"}
              </h2>
              <p className="mx-auto mt-2 max-w-[280px] text-xs leading-5 text-slate-500">
                {title === "Đăng xuất"
                  ? "Bạn vẫn có thể quay lại và tiếp tục những chuyến đi đang lên kế hoạch."
                  : "Trò chuyện với đội ngũ Waygo hoặc xem câu hỏi thường gặp."}
              </p>
              <button className="advisor-primary mt-6">
                {title === "Đăng xuất" ? "Xác nhận đăng xuất" : "Bắt đầu trò chuyện"}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Navigation({
  active,
  onChange,
  tripReady,
  onLocked,
}: {
  active: Screen;
  onChange: (screen: Screen) => void;
  tripReady: boolean;
  onLocked: () => void;
}) {
  const items: { screen: Screen; label: string; icon: IconName }[] = [
    { screen: "explore", label: "Khám phá", icon: "home" },
    { screen: "planner", label: "Kế hoạch", icon: "calendar" },
    { screen: "bookings", label: "Đặt chỗ", icon: "ticket" },
    { screen: "profile", label: "Cá nhân", icon: "user" },
  ];
  return (
    <nav className="fixed bottom-0 left-1/2 z-40 flex w-full max-w-[480px] -translate-x-1/2 items-center justify-around border-t border-slate-100 bg-white/95 px-3 pb-[max(10px,env(safe-area-inset-bottom))] pt-2 backdrop-blur-xl dark:border-slate-800 dark:bg-slate-900/95">
      {items.map((item) => {
        const selected =
          active === item.screen || (active === "detail" && item.screen === "explore");
        const locked = !tripReady && (item.screen === "planner" || item.screen === "bookings");
        return (
          <button
            key={item.screen}
            onClick={() => (locked ? onLocked() : onChange(item.screen))}
            className={`relative flex min-w-16 flex-col items-center gap-1 py-1.5 text-[10px] font-semibold transition ${selected ? "text-[#0b74e5]" : locked ? "text-slate-300 dark:text-slate-600" : "text-slate-400"}`}
          >
            <Icon name={item.icon} size={21} className={selected ? "stroke-[2.4]" : ""} />
            <span>{item.label}</span>
            {locked && (
              <span className="absolute right-2 top-0 grid h-4 w-4 place-items-center rounded-full bg-slate-200 text-slate-500 ring-2 ring-white dark:bg-slate-700 dark:text-slate-300 dark:ring-slate-900">
                <Icon name="lock" size={9} />
              </span>
            )}
            {selected && <span className="absolute -top-2 h-1 w-5 rounded-full bg-[#0b74e5]" />}
          </button>
        );
      })}
    </nav>
  );
}

type AdvisorStep = "form" | "loading" | "results";

function TravelAdvisor({
  onClose,
  onConfirm,
}: {
  onClose: () => void;
  onConfirm: (destination: (typeof destinations)[number]) => void;
}) {
  const [step, setStep] = useState<AdvisorStep>("form");
  const [selectedId, setSelectedId] = useState("danang");
  const [moods, setMoods] = useState(["Biển", "Ẩm thực"]);
  const toggleMood = (mood: string) =>
    setMoods((current) =>
      current.includes(mood) ? current.filter((item) => item !== mood) : [...current, mood],
    );
  const findTrips = () => {
    setStep("loading");
    window.setTimeout(() => setStep("results"), 1500);
  };
  const selected = destinations.find((item) => item.id === selectedId) ?? destinations[0];

  return (
    <div className="fixed inset-0 z-[60] flex justify-center bg-[#f6f8fb] dark:bg-slate-950">
      <div className="min-h-screen w-full max-w-[480px] overflow-y-auto bg-[#f6f8fb] px-5 pb-8 pt-6 dark:bg-slate-950">
        {step === "form" && (
          <>
            <div className="mt-5 flex items-start justify-between">
              <div>
                <span className="inline-flex items-center gap-1.5 rounded-full bg-blue-50 px-2.5 py-1 text-[10px] font-bold text-[#0b74e5] dark:bg-blue-500/15">
                  <Icon name="sparkles" size={13} /> WAYGO AI
                </span>
                <h2 className="mt-3 text-[24px] font-extrabold leading-tight tracking-tight">
                  Chuyến đi trong mơ
                  <br />
                  của bạn trông thế nào?
                </h2>
                <p className="mt-2 text-xs leading-5 text-slate-500">
                  Chia sẻ một chút, Waygo sẽ tìm nơi thật hợp với bạn.
                </p>
              </div>
              <button onClick={onClose} className="icon-button shrink-0 text-lg">
                ×
              </button>
            </div>

            <div className="mt-6 space-y-5">
              <div>
                <p className="advisor-label">Bạn muốn đi khi nào?</p>
                <div className="mt-2 grid grid-cols-2 gap-3">
                  <label className="advisor-input">
                    <span>Từ ngày</span>
                    <input type="date" defaultValue="2025-08-12" />
                  </label>
                  <label className="advisor-input">
                    <span>Đến ngày</span>
                    <input type="date" defaultValue="2025-08-15" />
                  </label>
                </div>
              </div>
              <div>
                <p className="advisor-label">Bạn đi cùng ai?</p>
                <div className="mt-2 grid grid-cols-4 gap-2">
                  {["Một mình", "Cặp đôi", "Bạn bè", "Gia đình"].map((item, index) => (
                    <button
                      key={item}
                      className={`rounded-xl border px-1 py-3 text-[10px] font-bold transition ${index === 1 ? "border-blue-500 bg-blue-50 text-[#0b74e5] dark:bg-blue-500/15" : "border-slate-200 bg-white text-slate-500 dark:border-slate-700 dark:bg-slate-800"}`}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="flex justify-between">
                  <p className="advisor-label">Ngân sách dự kiến</p>
                  <strong className="text-xs text-[#0b74e5]">3–6 triệu / người</strong>
                </div>
                <input
                  type="range"
                  min="1"
                  max="10"
                  defaultValue="6"
                  className="mt-3 w-full accent-[#0b74e5]"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>Tiết kiệm</span>
                  <span>Thoải mái</span>
                </div>
              </div>
              <div>
                <p className="advisor-label">Bạn đang tìm kiếm điều gì?</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {["Biển", "Thiên nhiên", "Ẩm thực", "Văn hóa", "Nghỉ dưỡng", "Phiêu lưu"].map(
                    (item) => {
                      const active = moods.includes(item);
                      return (
                        <button
                          key={item}
                          onClick={() => toggleMood(item)}
                          className={`rounded-full border px-3.5 py-2 text-[11px] font-semibold transition ${active ? "border-[#0b74e5] bg-[#0b74e5] text-white" : "border-slate-200 bg-white text-slate-500 dark:border-slate-700 dark:bg-slate-800"}`}
                        >
                          {active && "✓ "}
                          {item}
                        </button>
                      );
                    },
                  )}
                </div>
              </div>
              <label className="block">
                <span className="advisor-label">Điều bạn đặc biệt mong muốn</span>
                <textarea
                  defaultValue="Muốn nơi có biển đẹp, đồ ăn ngon và không quá đông đúc."
                  className="mt-2 h-20 w-full resize-none rounded-2xl border border-slate-200 bg-white p-3 text-xs leading-5 outline-none focus:border-blue-400 dark:border-slate-700 dark:bg-slate-800"
                />
              </label>
            </div>
            <button onClick={findTrips} className="advisor-primary mt-6">
              <Icon name="sparkles" size={19} /> Để Gemini tìm điểm đến
            </button>
            <p className="mt-3 text-center text-[9px] text-slate-400">
              Bản demo giao diện · Kết quả AI đang được mô phỏng
            </p>
          </>
        )}

        {step === "loading" && (
          <div className="flex min-h-[520px] flex-col items-center justify-center text-center">
            <div className="ai-loader">
              <Icon name="sparkles" size={30} />
            </div>
            <h2 className="mt-7 text-xl font-extrabold">Gemini đang tìm kiếm...</h2>
            <p className="mt-2 max-w-[280px] text-xs leading-5 text-slate-500">
              Đang cân nhắc thời tiết, ngân sách và “mood” của bạn để tìm những nơi phù hợp nhất.
            </p>
            <div className="mt-7 flex gap-1.5">
              <span className="loading-dot" />
              <span className="loading-dot [animation-delay:150ms]" />
              <span className="loading-dot [animation-delay:300ms]" />
            </div>
          </div>
        )}

        {step === "results" && (
          <>
            <div className="mt-5 flex items-start justify-between">
              <div>
                <span className="inline-flex items-center gap-1.5 text-[10px] font-bold text-emerald-600">
                  <Icon name="check" size={14} /> ĐÃ PHÂN TÍCH XONG
                </span>
                <h2 className="mt-2 text-2xl font-extrabold tracking-tight">
                  3 nơi rất hợp với bạn
                </h2>
                <p className="mt-1 text-xs text-slate-500">Chọn một nơi để bắt đầu lên kế hoạch.</p>
              </div>
              <button onClick={onClose} className="icon-button text-lg">
                ×
              </button>
            </div>
            <div className="mt-5 space-y-3">
              {destinations.map((item, index) => {
                const chosen = selectedId === item.id;
                const match = ["96%", "91%", "87%"][index];
                const reasons = [
                  "Biển đẹp · Ẩm thực phong phú · Đúng ngân sách",
                  "Văn hóa đặc sắc · Không gian lãng mạn",
                  "Thiên nhiên kỳ vĩ · Trải nghiệm thư giãn",
                ][index];
                return (
                  <button
                    key={item.id}
                    onClick={() => setSelectedId(item.id)}
                    className={`flex w-full gap-3 rounded-2xl border-2 bg-white p-2.5 text-left transition dark:bg-slate-800 ${chosen ? "border-[#0b74e5] shadow-[0_8px_25px_rgba(11,116,229,.12)]" : "border-transparent"}`}
                  >
                    <img
                      src={item.image}
                      alt={item.name}
                      className="h-24 w-24 rounded-xl object-cover"
                    />
                    <div className="min-w-0 flex-1 py-1">
                      <div className="flex items-center justify-between gap-2">
                        <h3 className="font-extrabold">{item.name}</h3>
                        <span className="rounded-lg bg-emerald-50 px-2 py-1 text-[10px] font-extrabold text-emerald-600 dark:bg-emerald-500/15">
                          {match} hợp
                        </span>
                      </div>
                      <p className="mt-1 line-clamp-2 text-[10px] leading-4 text-slate-500">
                        {reasons}
                      </p>
                      <div className="mt-2 flex items-center justify-between">
                        <span className="text-[10px] text-slate-400">
                          Từ{" "}
                          <strong className="text-xs text-slate-700 dark:text-slate-200">
                            {item.price}
                          </strong>
                        </span>
                        <span
                          className={`grid h-5 w-5 place-items-center rounded-full border-2 ${chosen ? "border-[#0b74e5] bg-[#0b74e5] text-white" : "border-slate-300"}`}
                        >
                          {chosen && <Icon name="check" size={12} />}
                        </span>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
            <div className="mt-4 rounded-xl bg-blue-50 p-3 text-[10px] leading-4 text-blue-700 dark:bg-blue-500/10 dark:text-blue-300">
              <strong>Vì sao chọn {selected.name}?</strong> Phù hợp nhất với ngân sách, thời gian và
              sở thích bạn vừa chia sẻ.
            </div>
            <button onClick={() => onConfirm(selected)} className="advisor-primary mt-5">
              Chọn {selected.name} & tạo kế hoạch <Icon name="arrow" size={19} />
            </button>
            <button
              onClick={() => setStep("form")}
              className="mt-3 w-full py-2 text-xs font-bold text-slate-500"
            >
              Thay đổi yêu cầu
            </button>
          </>
        )}
      </div>
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("explore");
  const [dark, setDark] = useState(false);
  const [advisorOpen, setAdvisorOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState(categories[0]);
  const [detailDestination, setDetailDestination] = useState(destinations[0]);
  const [detailBack, setDetailBack] = useState<Screen>("explore");
  const [profilePage, setProfilePage] = useState("Địa điểm đã lưu");
  const [selectedDestination, setSelectedDestination] = useState<
    (typeof destinations)[number] | null
  >(null);
  const openDetail = (destination: (typeof destinations)[number], back: Screen = "explore") => {
    setDetailDestination(destination);
    setDetailBack(back);
    setScreen("detail");
  };
  const primaryScreens: Screen[] = ["explore", "planner", "bookings", "profile"];
  return (
    <div className={dark ? "dark" : ""}>
      <main className="min-h-screen bg-[#f6f8fb] text-slate-900 transition-colors dark:bg-slate-950 dark:text-slate-100">
        <div className="mx-auto min-h-screen w-full max-w-[480px] overflow-hidden bg-[#f6f8fb] shadow-[0_0_70px_rgba(15,45,80,.1)] transition-colors dark:bg-slate-950">
          {screen === "explore" && (
            <Explore
              onDetail={(destination) => openDetail(destination)}
              onOpenAdvisor={() => setAdvisorOpen(true)}
              onCategory={(category) => {
                setSelectedCategory(category);
                setScreen("service");
              }}
              onOpenMap={() => setScreen("map")}
              onSeeAll={() => setScreen("destinations")}
              onNotifications={() => setScreen("notifications")}
              dark={dark}
              setDark={setDark}
            />
          )}
          {screen === "planner" && selectedDestination && (
            <Planner destination={selectedDestination} />
          )}
          {screen === "bookings" && selectedDestination && (
            <Bookings destination={selectedDestination} />
          )}
          {screen === "profile" && (
            <Profile
              dark={dark}
              setDark={setDark}
              onOpenItem={(label) => {
                setProfilePage(label);
                setScreen("profile-detail");
              }}
            />
          )}
          {screen === "detail" && (
            <Detail
              destination={detailDestination}
              onBack={() => setScreen(detailBack)}
              onOpenMap={() => setScreen("map")}
            />
          )}
          {screen === "service" && (
            <ServicePage category={selectedCategory} onBack={() => setScreen("explore")} />
          )}
          {screen === "destinations" && (
            <DestinationsPage
              onBack={() => setScreen("explore")}
              onDetail={(destination) => openDetail(destination, "destinations")}
            />
          )}
          {screen === "notifications" && (
            <NotificationsPage onBack={() => setScreen("explore")} />
          )}
          {screen === "map" && <MapPage onBack={() => setScreen("explore")} />}
          {screen === "profile-detail" && (
            <ProfileDetailPage title={profilePage} onBack={() => setScreen("profile")} />
          )}
          {primaryScreens.includes(screen) && (
            <Navigation
              active={screen}
              onChange={setScreen}
              tripReady={Boolean(selectedDestination)}
              onLocked={() => setAdvisorOpen(true)}
            />
          )}
          {advisorOpen && (
            <TravelAdvisor
              onClose={() => setAdvisorOpen(false)}
              onConfirm={(destination) => {
                setSelectedDestination(destination);
                setAdvisorOpen(false);
                setScreen("planner");
              }}
            />
          )}
        </div>
      </main>
    </div>
  );
}
